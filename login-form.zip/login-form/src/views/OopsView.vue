<template>
  <div class="oops">
    <h2 class="oops-text">OOPS 404: ТАКУЮ СТРАНИЦУ НЕ НАШЛИ!</h2>
  </div>
</template>

<script setup lang="ts"></script>
<style scoped>
.oops {
  width: 100%;
  height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
}
.oops-text {
  font-size: xx-large;
}
</style>
